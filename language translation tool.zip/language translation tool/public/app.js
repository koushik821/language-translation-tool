// --- Constants and Mappings ---
const LANGUAGE_NAMES = {
  auto: 'Detect Language',
  en: 'English',
  es: 'Spanish',
  fr: 'French',
  de: 'German',
  it: 'Italian',
  pt: 'Portuguese',
  ru: 'Russian',
  zh: 'Chinese',
  ja: 'Japanese',
  ko: 'Korean',
  ar: 'Arabic',
  hi: 'Hindi',
  nl: 'Dutch',
  tr: 'Turkish',
  pl: 'Polish',
  sv: 'Swedish',
  vi: 'Vietnamese'
};

const LANGUAGE_SPEECH_CODES = {
  en: 'en-US',
  es: 'es-ES',
  fr: 'fr-FR',
  de: 'de-DE',
  it: 'it-IT',
  pt: 'pt-PT',
  ru: 'ru-RU',
  zh: 'zh-CN',
  ja: 'ja-JP',
  ko: 'ko-KR',
  ar: 'ar-SA',
  hi: 'hi-IN',
  nl: 'nl-NL',
  tr: 'tr-TR',
  pl: 'pl-PL',
  sv: 'sv-SE',
  vi: 'vi-VN'
};

// --- DOM Elements ---
const sourceLangSelect = document.getElementById('sourceLangSelect');
const targetLangSelect = document.getElementById('targetLangSelect');
const sourceTextArea = document.getElementById('sourceTextArea');
const targetTextArea = document.getElementById('targetTextArea');
const swapLanguagesBtn = document.getElementById('swapLanguagesBtn');
const clearTextBtn = document.getElementById('clearTextBtn');
const sourceSpeechBtn = document.getElementById('sourceSpeechBtn');
const targetSpeechBtn = document.getElementById('targetSpeechBtn');
const copyTextBtn = document.getElementById('copyTextBtn');
const copyTooltip = document.getElementById('copyTooltip');
const charCounter = document.getElementById('charCounter');
const statusText = document.getElementById('statusText');
const autoTranslateToggle = document.getElementById('autoTranslateToggle');
const translateBtn = document.getElementById('translateBtn');
const translationLoader = document.getElementById('translationLoader');
const historyList = document.getElementById('historyList');
const clearHistoryBtn = document.getElementById('clearHistoryBtn');

// --- State Variables ---
let translateTimeout = null;
let currentDetectedLang = null;

// --- Event Listeners Initialization ---
document.addEventListener('DOMContentLoaded', () => {
  // Input and buttons events
  sourceTextArea.addEventListener('input', handleSourceInput);
  translateBtn.addEventListener('click', () => performTranslation(true));
  swapLanguagesBtn.addEventListener('click', swapLanguages);
  clearTextBtn.addEventListener('click', clearSourceText);
  
  // Speech & Copy events
  sourceSpeechBtn.addEventListener('click', speakSourceText);
  targetSpeechBtn.addEventListener('click', speakTargetText);
  copyTextBtn.addEventListener('click', copyTranslation);
  
  // Settings/Selects
  sourceLangSelect.addEventListener('change', () => {
    updateClearBtnVisibility();
    if (autoTranslateToggle.checked) performTranslation();
  });
  targetLangSelect.addEventListener('change', () => {
    if (autoTranslateToggle.checked) performTranslation();
  });
  
  clearHistoryBtn.addEventListener('click', clearAllHistory);

  // Initialize Web Speech voices loading (Chrome/Safari voice async load)
  if (typeof speechSynthesis !== 'undefined' && speechSynthesis.onvoiceschanged !== undefined) {
    speechSynthesis.onvoiceschanged = () => {}; 
  }

  // Initial UI Render
  updateClearBtnVisibility();
  renderHistory();
});

// --- Core Logic ---

// Clear button visibility
function updateClearBtnVisibility() {
  const hasText = sourceTextArea.value.trim().length > 0;
  if (hasText) {
    clearTextBtn.classList.add('active');
  } else {
    clearTextBtn.classList.remove('active');
  }
}

// Character counter updater
function updateCharCounter() {
  const len = sourceTextArea.value.length;
  charCounter.textContent = `${len} / 5000`;
}

// Handle key/input typing inside source area
function handleSourceInput() {
  updateCharCounter();
  updateClearBtnVisibility();
  
  if (sourceTextArea.value.trim() === '') {
    targetTextArea.value = '';
    setStatus('Ready', 'ready');
    return;
  }

  if (autoTranslateToggle.checked) {
    // Clear preceding delay
    clearTimeout(translateTimeout);
    setStatus('Typing...', 'translating');
    
    // Set 600ms debounce
    translateTimeout = setTimeout(() => {
      performTranslation();
    }, 600);
  }
}

// Perform API Translation Request
async function performTranslation(force = false) {
  const text = sourceTextArea.value.trim();
  const sourceLang = sourceLangSelect.value;
  const targetLang = targetLangSelect.value;

  if (!text) {
    targetTextArea.value = '';
    return;
  }

  // Prevent API requests if Auto-Translate is off and it's not a manual click
  if (!force && !autoTranslateToggle.checked) {
    return;
  }

  setStatus('Translating...', 'translating');
  translationLoader.classList.add('active');

  try {
    const response = await fetch('/api/translate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, sourceLang, targetLang })
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || 'Server error occurred during translation');
    }

    targetTextArea.value = data.translatedText;
    setStatus('Translated', 'success');

    // Attempt to read out autodetected language
    if (sourceLang === 'auto' && data.matches && data.matches.length > 0) {
      // Find if we have matches that give us details
      const primaryMatch = data.matches[0];
      // Keep it simple
    }

    // Save translation to localStorage history
    saveToHistory(text, data.translatedText, sourceLang, targetLang);

  } catch (err) {
    console.error(err);
    targetTextArea.value = '';
    setStatus('Error translating text', 'error');
  } finally {
    translationLoader.classList.remove('active');
  }
}

// Clear source input
function clearSourceText() {
  sourceTextArea.value = '';
  targetTextArea.value = '';
  updateCharCounter();
  updateClearBtnVisibility();
  setStatus('Ready', 'ready');
  window.speechSynthesis.cancel();
}

// Swap languages logic
function swapLanguages() {
  const currentSource = sourceLangSelect.value;
  const currentTarget = targetLangSelect.value;

  // We cannot swap 'auto' to the target language select directly because it's only for source
  if (currentSource === 'auto') {
    // Default the new target language to English or Spanish depending on current target
    sourceLangSelect.value = currentTarget;
    targetLangSelect.value = 'en';
  } else {
    sourceLangSelect.value = currentTarget;
    targetLangSelect.value = currentSource;
  }

  // Swap texts if target text area has contents
  const currentSourceText = sourceTextArea.value.trim();
  const currentTargetText = targetTextArea.value.trim();

  if (currentTargetText) {
    sourceTextArea.value = currentTargetText;
    targetTextArea.value = currentSourceText;
    updateCharCounter();
    updateClearBtnVisibility();
  }

  // Trigger translation for swapped state
  performTranslation(true);
}

// Speak source text using Web Speech synthesis
function speakSourceText() {
  const text = sourceTextArea.value.trim();
  let lang = sourceLangSelect.value;
  
  if (!text) return;
  if (lang === 'auto') {
    // If it's autodetected, fallback to default English or try to read from state if we can
    lang = 'en';
  }
  
  speakText(text, lang, sourceSpeechBtn);
}

// Speak target text using Web Speech synthesis
function speakTargetText() {
  const text = targetTextArea.value.trim();
  const lang = targetLangSelect.value;
  
  if (!text) return;
  
  speakText(text, lang, targetSpeechBtn);
}

// Speak utility
function speakText(text, lang, buttonEl) {
  if (!('speechSynthesis' in window)) {
    alert('Your browser does not support text-to-speech.');
    return;
  }

  window.speechSynthesis.cancel(); // Stop active speaker

  const speechCode = LANGUAGE_SPEECH_CODES[lang] || 'en-US';
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = speechCode;

  // Select suitable voice
  const voices = window.speechSynthesis.getVoices();
  const matchedVoice = voices.find(v => v.lang.startsWith(lang) || v.lang.includes(speechCode));
  if (matchedVoice) {
    utterance.voice = matchedVoice;
  }

  // Button state styling during speaking
  buttonEl.classList.add('active');
  utterance.onend = () => {
    buttonEl.classList.remove('active');
  };
  utterance.onerror = () => {
    buttonEl.classList.remove('active');
  };

  window.speechSynthesis.speak(utterance);
}

// Copy to Clipboard
function copyTranslation() {
  const text = targetTextArea.value.trim();
  if (!text) return;

  navigator.clipboard.writeText(text)
    .then(() => {
      // Toggle Tooltip
      copyTooltip.classList.add('show');
      copyTextBtn.classList.add('active');
      
      setTimeout(() => {
        copyTooltip.classList.remove('show');
        copyTextBtn.classList.remove('active');
      }, 2000);
    })
    .catch(err => {
      console.error('Failed to copy text: ', err);
    });
}

// Set Status Bar Text and Class
function setStatus(message, stateClass) {
  statusText.textContent = message;
  statusText.className = 'status-indicator'; // Reset classes
  if (stateClass) {
    statusText.classList.add(stateClass);
  }
}

// --- LocalStorage History Management ---

function saveToHistory(sourceText, translatedText, sourceLang, targetLang) {
  // Exclude duplicate/identical saves of text
  let history = getHistory();
  const isDuplicate = history.some(item => 
    item.sourceText.toLowerCase() === sourceText.toLowerCase() && 
    item.sourceLang === sourceLang && 
    item.targetLang === targetLang
  );

  if (isDuplicate) return;

  const historyItem = {
    id: Date.now().toString(),
    sourceText,
    translatedText,
    sourceLang,
    targetLang,
    sourceLangName: LANGUAGE_NAMES[sourceLang] || sourceLang,
    targetLangName: LANGUAGE_NAMES[targetLang] || targetLang,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  };

  history.unshift(historyItem);
  
  // Limit to 10 latest items
  if (history.length > 10) {
    history = history.slice(0, 10);
  }

  localStorage.setItem('translation_history', JSON.stringify(history));
  renderHistory();
}

function getHistory() {
  const items = localStorage.getItem('translation_history');
  return items ? JSON.parse(items) : [];
}

function deleteHistoryItem(id, event) {
  event.stopPropagation(); // Avoid triggering restoring when clicking delete
  let history = getHistory();
  history = history.filter(item => item.id !== id);
  localStorage.setItem('translation_history', JSON.stringify(history));
  renderHistory();
}

function clearAllHistory() {
  localStorage.removeItem('translation_history');
  renderHistory();
}

function restoreHistoryItem(item) {
  sourceLangSelect.value = item.sourceLang;
  targetLangSelect.value = item.targetLang;
  sourceTextArea.value = item.sourceText;
  targetTextArea.value = item.translatedText;
  
  updateCharCounter();
  updateClearBtnVisibility();
  setStatus('Restored from history', 'success');
  
  // Highlight the card temporary for visual feedback
  const card = document.getElementById('translatorCard');
  card.style.boxShadow = '0 0 35px rgba(6, 182, 212, 0.4)';
  setTimeout(() => {
    card.style.boxShadow = '';
  }, 1000);
}

function renderHistory() {
  const history = getHistory();
  
  if (history.length === 0) {
    historyList.innerHTML = `
      <div class="history-empty">
        <i class="fa-regular fa-folder-open"></i>
        <p>Your translation history is empty</p>
      </div>
    `;
    return;
  }

  historyList.innerHTML = '';
  history.forEach(item => {
    const itemEl = document.createElement('div');
    itemEl.className = 'history-item history-item-clickable';
    itemEl.addEventListener('click', () => restoreHistoryItem(item));

    itemEl.innerHTML = `
      <div class="history-item-header">
        <div class="history-langs">
          <span>${item.sourceLangName}</span>
          <i class="fa-solid fa-arrow-right"></i>
          <span>${item.targetLangName}</span>
        </div>
        <button class="delete-item-btn" title="Delete record" aria-label="Delete history record">
          <i class="fa-solid fa-trash"></i>
        </button>
      </div>
      <div class="history-texts">
        <div class="history-text-col">
          <span class="history-label">Original</span>
          <span class="history-text-val">${escapeHTML(item.sourceText)}</span>
        </div>
        <div class="history-text-col">
          <span class="history-label">Translation</span>
          <span class="history-text-val target">${escapeHTML(item.translatedText)}</span>
        </div>
      </div>
      <div class="restore-history-indicator">
        <i class="fa-solid fa-arrow-turn-up"></i>
        <span>Restore</span>
      </div>
    `;

    // Attach listener for delete button specifically
    const deleteBtn = itemEl.querySelector('.delete-item-btn');
    deleteBtn.addEventListener('click', (e) => deleteHistoryItem(item.id, e));

    historyList.appendChild(itemEl);
  });
}

// Utility to clean rendering strings to avoid HTML injection
function escapeHTML(str) {
  return str.replace(/[&<>'"]/g, 
    tag => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      "'": '&#39;',
      '"': '&quot;'
    }[tag] || tag)
  );
}

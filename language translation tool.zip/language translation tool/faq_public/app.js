document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements
  const chatMessages = document.getElementById('chatMessages');
  const chatForm = document.getElementById('chatForm');
  const userInput = document.getElementById('userInput');
  const sendBtn = document.getElementById('sendBtn');
  const quickSuggestions = document.getElementById('quickSuggestions');
  const faqAccordion = document.getElementById('faqAccordion');
  const toggleInspectorBtn = document.getElementById('toggleInspectorBtn');
  const closeInspectorBtn = document.getElementById('closeInspectorBtn');
  const nlpInspector = document.getElementById('nlpInspector');
  const categoryItems = document.querySelectorAll('.category-item');

  // NLP Inspector DOM Elements
  const scoreCircle = document.getElementById('scoreCircle');
  const scoreText = document.getElementById('scoreText');
  const matchStatus = document.getElementById('matchStatus');
  const origQuestion = document.getElementById('origQuestion');
  const tokenOutput = document.getElementById('tokenOutput');
  const preprocessedStr = document.getElementById('preprocessedStr');
  const matchedFaqKey = document.getElementById('matchedFaqKey');

  // Global variables
  let allFaqs = [];
  const BACKEND_URL = 'http://127.0.0.1:5000'; // Flask backend endpoint

  // 1. Fetch FAQs and load sidebar accordion
  async function loadFaqs() {
    try {
      const response = await fetch(`${BACKEND_URL}/api/faqs`);
      if (!response.ok) throw new Error('Failed to fetch FAQs');
      
      allFaqs = await response.json();
      renderAccordion(allFaqs);
    } catch (error) {
      console.error('Error fetching FAQs:', error);
      faqAccordion.innerHTML = '<div class="accordion-loader" style="color: #ff3366;"><i class="fa-solid fa-triangle-exclamation"></i> Error loading FAQs. Make sure backend is running.</div>';
    }
  }

  // 2. Render Accordion Items
  function renderAccordion(faqsToRender) {
    if (faqsToRender.length === 0) {
      faqAccordion.innerHTML = '<div class="accordion-loader">No FAQs found in this category.</div>';
      return;
    }

    faqAccordion.innerHTML = '';
    faqsToRender.forEach(faq => {
      const accordionItem = document.createElement('div');
      accordionItem.className = 'accordion-item';
      accordionItem.innerHTML = `
        <div class="accordion-header">
          <span>${faq.question}</span>
          <i class="fa-solid fa-chevron-down"></i>
        </div>
        <div class="accordion-content">
          <div class="accordion-body">${faq.answer}</div>
        </div>
      `;

      // Accordion toggle click handler
      const header = accordionItem.querySelector('.accordion-header');
      const content = accordionItem.querySelector('.accordion-content');
      
      header.addEventListener('click', () => {
        const isOpen = accordionItem.classList.contains('open');
        
        // Close all other items
        document.querySelectorAll('.accordion-item').forEach(item => {
          item.classList.remove('open');
          item.querySelector('.accordion-content').style.maxHeight = null;
        });

        if (!isOpen) {
          accordionItem.classList.add('open');
          content.style.maxHeight = content.scrollHeight + 'px';
          // Also set this question to user input as a convenience
          userInput.value = faq.question;
          userInput.focus();
        }
      });

      faqAccordion.appendChild(accordionItem);
    });
  }

  // 3. Category Filter
  categoryItems.forEach(item => {
    item.addEventListener('click', () => {
      categoryItems.forEach(c => c.classList.remove('active'));
      item.classList.add('active');

      const selectedCategory = item.getAttribute('data-category');
      
      if (selectedCategory === 'all') {
        renderAccordion(allFaqs);
      } else {
        const filtered = allFaqs.filter(faq => faq.category === selectedCategory);
        renderAccordion(filtered);
      }
    });
  });

  // 4. Send Message to Chat and Backend
  async function sendMessage(question) {
    if (!question.trim()) return;

    // Append user bubble
    appendMessage(question, 'user');
    userInput.value = '';
    
    // Disable inputs and show typing indicator
    setInputState(false);
    const typingIndicatorElement = appendTypingIndicator();
    
    // Auto scroll
    scrollToBottom();

    // Prepare inspector input log
    origQuestion.textContent = `"${question}"`;

    try {
      const response = await fetch(`${BACKEND_URL}/api/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ question })
      });

      const data = await response.json();
      
      // Remove typing indicator
      typingIndicatorElement.remove();
      setInputState(true);

      // Append bot bubble
      appendMessage(data.answer, 'bot');
      scrollToBottom();

      // Update Inspector Panel
      updateInspector(data);

    } catch (error) {
      console.error('Chat error:', error);
      typingIndicatorElement.remove();
      setInputState(true);
      
      appendMessage("Connection lost. Please make sure the Flask server is running at http://127.0.0.1:5000.", "bot");
      scrollToBottom();

      // Reset inspector score on error
      resetInspectorError();
    }
  }

  // Helper: Append Message Bubble
  function appendMessage(text, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-message`;
    
    const icon = sender === 'bot' ? 'fa-robot' : 'fa-user-astronaut';
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    messageDiv.innerHTML = `
      <div class="msg-avatar"><i class="fa-solid ${icon}"></i></div>
      <div class="msg-content-wrapper">
        <div class="msg-content">${text}</div>
        <span class="msg-time">${timestamp}</span>
      </div>
    `;

    chatMessages.appendChild(messageDiv);
  }

  // Helper: Append Typing Indicator
  function appendTypingIndicator() {
    const indicatorDiv = document.createElement('div');
    indicatorDiv.className = 'message bot-message';
    indicatorDiv.id = 'typingIndicator';
    indicatorDiv.innerHTML = `
      <div class="msg-avatar"><i class="fa-solid fa-robot"></i></div>
      <div class="msg-content-wrapper">
        <div class="msg-content">
          <div class="typing-indicator">
            <span class="typing-dot"></span>
            <span class="typing-dot"></span>
            <span class="typing-dot"></span>
          </div>
        </div>
      </div>
    `;
    chatMessages.appendChild(indicatorDiv);
    return indicatorDiv;
  }

  // Helper: Enable/Disable Inputs
  function setInputState(enabled) {
    userInput.disabled = !enabled;
    sendBtn.disabled = !enabled;
    if (enabled) {
      userInput.focus();
    }
  }

  // Helper: Scroll to bottom of chat
  function scrollToBottom() {
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  // 5. Update NLP Inspector
  function updateInspector(data) {
    const score = data.score || 0;
    const scorePct = Math.round(score * 100);

    // Update circular gauge
    scoreText.textContent = `${scorePct}%`;
    scoreCircle.setAttribute('stroke-dasharray', `${scorePct}, 100`);

    // Reset gauge color class
    scoreCircle.className.baseVal = 'circle';
    
    let status = 'NO MATCH';
    if (data.intent) {
      status = `INTENT MATCH (${data.intent.toUpperCase()})`;
      scoreCircle.classList.add('score-high');
    } else if (score >= 0.6) {
      status = 'HIGH CONFIDENCE';
      scoreCircle.classList.add('score-high');
    } else if (score >= 0.25) {
      status = 'MEDIUM CONFIDENCE';
      scoreCircle.classList.add('score-mid');
    } else {
      status = 'LOW CONFIDENCE / FALLBACK';
      scoreCircle.classList.add('score-low');
    }
    matchStatus.textContent = status;

    // Update tokens list
    tokenOutput.innerHTML = '';
    if (data.tokens && data.tokens.length > 0) {
      data.tokens.forEach(token => {
        const tokenSpan = document.createElement('span');
        tokenSpan.className = 'token';
        tokenSpan.textContent = token;
        tokenOutput.appendChild(tokenSpan);
      });
    } else {
      tokenOutput.innerHTML = '<span class="empty-token">No tokens remaining</span>';
    }

    // Update lemmatized string
    preprocessedStr.textContent = data.preprocessed && data.preprocessed.trim() !== '' 
      ? `"${data.preprocessed}"` 
      : 'None (Filtered out)';

    // Update matched key
    matchedFaqKey.textContent = data.matched_question || 'None';

    // Highlight text matching if it was successful
    if (data.success && score >= 0.25) {
      matchedFaqKey.style.color = 'var(--accent-cyan)';
    } else {
      matchedFaqKey.style.color = 'var(--text-muted)';
    }
  }

  function resetInspectorError() {
    scoreText.textContent = '0%';
    scoreCircle.setAttribute('stroke-dasharray', '0, 100');
    scoreCircle.className.baseVal = 'circle score-low';
    matchStatus.textContent = 'SERVER ERROR';
    tokenOutput.innerHTML = '<span class="empty-token">Error</span>';
    preprocessedStr.textContent = 'Error';
    matchedFaqKey.textContent = 'Error';
  }

  // 6. Form Submission Event
  chatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const question = userInput.value;
    sendMessage(question);
  });

  // 7. Quick suggestions event
  quickSuggestions.addEventListener('click', (e) => {
    const chip = e.target.closest('.chip');
    if (chip) {
      const question = chip.getAttribute('data-question');
      sendMessage(question);
    }
  });

  // 8. Toggle NLP Inspector
  toggleInspectorBtn.addEventListener('click', () => {
    nlpInspector.classList.toggle('closed');
  });

  closeInspectorBtn.addEventListener('click', () => {
    nlpInspector.classList.add('closed');
  });

  // Startup: Load FAQ data
  loadFaqs();
});

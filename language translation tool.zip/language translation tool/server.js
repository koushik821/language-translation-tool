const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Enable CORS and JSON parsing
app.use(cors());
app.use(express.json());

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Translation Endpoint
app.post('/api/translate', async (req, res) => {
  try {
    const { text, sourceLang, targetLang } = req.body;

    if (!text || text.trim() === '') {
      return res.status(400).json({ error: 'Text to translate is required' });
    }

    if (!targetLang) {
      return res.status(400).json({ error: 'Target language is required' });
    }

    const source = (sourceLang && sourceLang !== 'auto') ? sourceLang : 'autodetect';
    const target = targetLang;

    // Use MyMemory API: https://mymemory.translated.net/doc/spec.php
    // API format: https://api.mymemory.translated.net/get?q=TEXT&langpair=SOURCE|TARGET
    const langpair = `${source}|${target}`;
    const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${encodeURIComponent(langpair)}`;

    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Translation API returned status ${response.status}`);
    }

    const data = await response.json();

    if (data.responseStatus !== 200) {
      // MyMemory returns detailed error messages in responseData or as text
      const errorMessage = data.responseDetails || 'Translation failed';
      return res.status(data.responseStatus).json({ error: errorMessage });
    }

    const translatedText = data.responseData.translatedText;
    
    // Check if a match occurred
    if (!translatedText) {
      return res.status(500).json({ error: 'Translation API did not return any translation.' });
    }

    // Return the response
    res.json({
      translatedText,
      sourceLang: source,
      targetLang: target,
      matches: data.matches || []
    });

  } catch (error) {
    console.error('Translation error:', error);
    res.status(500).json({
      error: 'An internal server error occurred while processing the translation.'
    });
  }
});

// Fallback to index.html for single-page style experience
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
  console.log(`Open http://localhost:${PORT} in your browser`);
});

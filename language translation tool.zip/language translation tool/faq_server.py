import os
import sys
import json
import re
from flask import Flask, request, jsonify
from flask_cors import CORS

# ---------------------------------------------------------
# NLTK Setup
# ---------------------------------------------------------
print("Initializing NLTK resources...")
import nltk

def download_nltk_resource(resource_name, path_indicator):
    try:
        nltk.data.find(path_indicator)
        print(f"NLTK resource '{resource_name}' already exists.")
    except LookupError:
        print(f"Downloading NLTK resource '{resource_name}'...")
        nltk.download(resource_name)

# Download required NLTK resources
download_nltk_resource('punkt', 'tokenizers/punkt')
download_nltk_resource('punkt_tab', 'tokenizers/punkt_tab')
download_nltk_resource('stopwords', 'corpora/stopwords')
download_nltk_resource('wordnet', 'corpora/wordnet')

from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer

# ---------------------------------------------------------
# Flask App Setup
# ---------------------------------------------------------
app = Flask(__name__, static_folder='faq_public', static_url_path='')
CORS(app)

# Load FAQs from JSON database
FAQ_FILE_PATH = os.path.join(os.path.dirname(__file__), 'faq_data.json')
try:
    with open(FAQ_FILE_PATH, 'r', encoding='utf-8') as f:
        faqs = json.load(f)
except Exception as e:
    print(f"Error loading faq_data.json: {e}")
    faqs = []

# Initialize lemmatizer and stop words
lemmatizer = WordNetLemmatizer()
try:
    stop_words = set(stopwords.words('english'))
except Exception:
    stop_words = set()

# Preprocessing helper
def preprocess_text(text):
    """
    Cleans, tokenizes, removes stop words, and lemmatizes the input text.
    Returns: (list of tokens, preprocessed text string)
    """
    # 1. Lowercase
    text = text.lower()
    # 2. Remove special characters and numbers (keep letters and spaces)
    text = re.sub(r'[^a-z\s]', '', text)
    # 3. Tokenize
    tokens = word_tokenize(text)
    # 4. Remove stopwords and lemmatize
    cleaned_tokens = [lemmatizer.lemmatize(token) for token in tokens if token not in stop_words]
    
    return cleaned_tokens, " ".join(cleaned_tokens)

# Preprocess the FAQ database
print("Pre-indexing FAQ database...")
for faq in faqs:
    tokens, preprocessed = preprocess_text(faq['question'])
    faq['tokens'] = tokens
    faq['preprocessed_text'] = preprocessed

# Initialize TF-IDF and Fit Vectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

vectorizer = TfidfVectorizer()

# Build vector space if FAQs exist
if faqs:
    faq_corpus = [faq['preprocessed_text'] for faq in faqs]
    # Handle edge case where corpus is completely empty after preprocessing
    if any(text.strip() for text in faq_corpus):
        tfidf_matrix = vectorizer.fit_transform(faq_corpus)
    else:
        tfidf_matrix = None
else:
    tfidf_matrix = None

# Rule-based simple intents (Greetings, Farewells, Gratitude)
GREETINGS_PATTERN = re.compile(r'\b(hi|hello|hey|greetings|good\s+morning|good\s+afternoon|good\s+evening|yo)\b', re.IGNORECASE)
FAREWELLS_PATTERN = re.compile(r'\b(bye|goodbye|see\s+you|farewell|exit|quit)\b', re.IGNORECASE)
GRATITUDE_PATTERN = re.compile(r'\b(thanks|thank\s+you|thankyou|appreciate\s+it|grateful)\b', re.IGNORECASE)

def handle_basic_intents(question):
    """
    Checks for basic intents (greetings, farewells, gratitude).
    Returns (answer, intent_type) if matched, otherwise None.
    """
    q_clean = question.strip().lower()
    
    if GREETINGS_PATTERN.search(q_clean):
        return ("Hello traveler! I am Astra, your Cosmic Voyages assistant. How can I help you prepare for your journey to the stars today?", "greeting")
    elif FAREWELLS_PATTERN.search(q_clean):
        return ("Safe travels through the cosmos, explorer! Let me know if you need anything else before your launch.", "farewell")
    elif GRATITUDE_PATTERN.search(q_clean):
        return ("You are very welcome! It is my pleasure to assist you. May your trajectory be smooth!", "gratitude")
        
    return None

# ---------------------------------------------------------
# API Routes
# ---------------------------------------------------------

@app.route('/')
def serve_index():
    """Serves the main page."""
    return app.send_static_file('index.html')

@app.route('/api/faqs', methods=['GET'])
def get_faqs():
    """Returns the list of FAQs for UI quick-links."""
    # Exclude preprocessed fields from the response to keep it clean
    public_faqs = []
    for faq in faqs:
        public_faqs.append({
            "id": faq["id"],
            "category": faq["category"],
            "question": faq["question"],
            "answer": faq["answer"]
        })
    return jsonify(public_faqs)

@app.route('/api/chat', methods=['POST'])
def chat():
    """
    Matches the user's question with the most similar FAQ using cosine similarity.
    """
    data = request.json or {}
    user_question = data.get('question', '').strip()
    
    if not user_question:
        return jsonify({
            "answer": "Please ask a question! I am ready to help you.",
            "success": False
        }), 400

    # 1. Check basic rule-based intents
    intent_match = handle_basic_intents(user_question)
    if intent_match:
        answer, intent_type = intent_match
        q_tokens, q_preprocessed = preprocess_text(user_question)
        return jsonify({
            "answer": answer,
            "matched_question": f"[Intent: {intent_type.capitalize()}]",
            "score": 1.0,
            "tokens": q_tokens,
            "preprocessed": q_preprocessed,
            "intent": intent_type,
            "success": True
        })

    # 2. NLP Cosine Similarity Matching
    q_tokens, q_preprocessed = preprocess_text(user_question)
    
    if not q_preprocessed.strip() or tfidf_matrix is None:
        # Fallback if preprocessing leaves empty text (e.g. "what", "how", "the")
        return jsonify({
            "answer": "I'm not sure I understand. Could you please provide more details or ask about bookings, safety, baggage, or destinations like Mars?",
            "matched_question": "None (No meaningful keywords)",
            "score": 0.0,
            "tokens": q_tokens,
            "preprocessed": q_preprocessed,
            "success": False
        })
        
    try:
        # Vectorize query
        query_vector = vectorizer.transform([q_preprocessed])
        
        # Calculate cosine similarity with all FAQs
        similarities = cosine_similarity(query_vector, tfidf_matrix).flatten()
        
        # Find best match
        best_match_idx = similarities.argmax()
        best_score = float(similarities[best_match_idx])
        
        # Set a similarity threshold
        SIMILARITY_THRESHOLD = 0.25
        
        if best_score >= SIMILARITY_THRESHOLD:
            best_faq = faqs[best_match_idx]
            return jsonify({
                "answer": best_faq['answer'],
                "matched_question": best_faq['question'],
                "score": round(best_score, 4),
                "tokens": q_tokens,
                "preprocessed": q_preprocessed,
                "category": best_faq['category'],
                "success": True
            })
        else:
            # Fallback if similarity score is too low
            return jsonify({
                "answer": "I'm sorry, I couldn't find a direct FAQ answer for that. I can help with bookings, launch requirements, luggage guidelines, communication delays, or space sickness. Please try rephrasing, or check the common questions list below.",
                "matched_question": f"None (Closest was '{faqs[best_match_idx]['question']}' with score {round(best_score, 3)})",
                "score": round(best_score, 4),
                "tokens": q_tokens,
                "preprocessed": q_preprocessed,
                "success": False
            })
            
    except Exception as e:
        print(f"Error during matching: {e}")
        return jsonify({
            "answer": "Oops, an error occurred in my neural mapping arrays. Let me reset and try again. What can I help you with?",
            "success": False,
            "error": str(e)
        }), 500

# ---------------------------------------------------------
# Run Server
# ---------------------------------------------------------
if __name__ == '__main__':
    PORT = 5000
    print(f"Starting Astra FAQ Chatbot server on port {PORT}...")
    app.run(host='0.0.0.0', port=PORT, debug=True)
